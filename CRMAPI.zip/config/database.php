<?php
/**
 * Database Configuration
 */

return [
    'host' => 'localhost',
    'database' => 'vconn',
    'username' => 'root',
    'password' => 'Dell@123!@#',
    'charset' => 'utf8mb4',
    'port' => 3306
];




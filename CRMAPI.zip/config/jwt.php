<?php
/**
 * JWT Configuration
 */

return [
    'secret_key' => 'vtiger_crm_api_secret_key_change_in_production',
    'algorithm' => 'HS256',
    'expiration' => 86400 // 24 hours in seconds
];



